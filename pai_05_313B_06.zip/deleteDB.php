<?php
  $server = 'localhost';
  $user = 'root';
  $pass = 'admin';
  $connect = mysql_connect($server, $user, $pass);
  mysql_query( 'DROP DATABASE 313b',$connect);
?>