#### Baza danych: ####

nazwa: 313b

login: root
has�o: admin

Uwaga: baza danych tworzona jest poprzez wej�cie na stron� g��wn� portalu - index.php.
Drugi spos�b: uruchomienie createDB.php

#### Domy�lny login oraz has�o administratora do panelu admina ####

login: admin
has�o: admin

#### Domy�lny login oraz has�o u�ytkownika do forum (sekcja u�ytkownika) ####

login: admin
has�o: admin

#### Informacje wa�ne####

Wersja PHP: 5.6.31

W pliku createDB.php u�yto frazy: error_reporting(E_ALL &~ E_DEPRECATED) celem pozbycia si�
informacji zwracanej przez PHP o zast�pieniu funkcji mysql_query w nast�pnych wersjach PHP przez
funkcj� mysqli_query. 

W przypadku wersji PHP mniejszej od 5.3.0 oraz wyst�puj�cych notatek na stronach o nieznanym poleceniu
zaleca si� zakomentowanie tej linijki, poniewa� dopiero od wersji 5.3.0 E_DEPRECATED zosta�o wprowadzone.
